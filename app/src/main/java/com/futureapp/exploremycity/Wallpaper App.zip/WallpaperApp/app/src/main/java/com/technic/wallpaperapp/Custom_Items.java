package com.technic.wallpaperapp;

public class Custom_Items {
   public String images;


    public Custom_Items(String images) {
        this.images = images;
    }



    public String getImages() {
        return images;

    }
}
